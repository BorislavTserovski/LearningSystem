﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LearningSystem.Services
{
    public class ServiceConstants
    {
        public const int BlogArticlePageSize = 25;
    }
}
