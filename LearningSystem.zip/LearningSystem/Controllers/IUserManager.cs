﻿namespace LearningSystem.Controllers
{
    internal interface IUserManager<T>
    {
    }
}